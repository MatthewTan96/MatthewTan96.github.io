# <Your Team ID> :G4T11
# <Team members' names> : Edwin Pang Bo Hao , Tan Hui Yi Vindy, Tan Qiu Long Matthew Ian

# replace the content of this function with your own algorithm
# from utility import *


def schedule_q1(orders, number_trucks):

  # location_dict = location_dict_generation([orders])
  #segment according to sections 
  order_in_sections = orders_per_sector(orders)
  # print(order_in_sections)
  number_of_orders_in_each_sector = number_of_orders_per_sector(order_in_sections)
  # print(number_of_orders_in_each_sector)

  #figure out the number of nodes that each truck has to do minimally
  nodes_per_truck = NodePerTruck(orders,number_trucks)
  # print(nodes_per_truck)

  #Find out how we allocate trucks per sector
  number_of_trucks_for_each_section = number_of_trucks_per_section(number_of_orders_in_each_sector,number_trucks,nodes_per_truck)
  # print(number_of_trucks_for_each_section)
  output = arrange_order_per_truck(order_in_sections,number_of_trucks_for_each_section)
  # print(output)
  last_out= []

  for element in output:
    output = validate(element)
    return output


def validate(lst):
  orders_received = []
  output1 = []

  #remove repeated elements 
  for array in lst:
    temp = []
    for element in array:
      if element not in orders_received:
        orders_received.append(element)
        temp.append(element)
    output1.append(temp)

  #Remove empty array 
  output2 = []
  for array in output1:
    if len(array) != 0:
        output2.append(array)

  return output2


def min_dist_node(lst,start_point):
    #calculate distance from origin and append to new list 
    #lst.sort(key = lambda x : (float(x[1])2 + float(x[2])**2)(1/2))
    #return lst
    order_dict = {}
    for i in range(len(lst)):
      start = start_point
      compare = lst[i]
      # print(start)
      # print(compare)
      #distance = math.sqrt(sum([(a - b) ** 2 for a, b in zip(x_coord, y_coord)]))
      distance = ((float(start[1])-float(compare[1]))**2 +(float(start[2])-float(compare[2]))**2)**0.5
      #print(distance)
      order_dict[lst[i][0]] = distance
    #print(order_dict)

    if order_dict=={}:
      return True

    min_node = min(order_dict,key=order_dict.get)
    
    # print(order_dict)
    for element in lst:
      if element[0] == min_node:
        # print(element)
        return element

#returns the sectors in [[s1],[s2],[s3],[s4]]
def orders_per_sector(orders):
  sec1 = []
  sec2 = []
  sec3 = []
  sec4 = []
  total_sec = []
  for order in orders:
    if float(order[1]) < 0 and float(order[2]) >= 0:
      sec1.append(order)
    elif float(order[1]) >= 0 and float(order[2]) >=0:
      sec2.append(order)
    elif float(order[1]) < 0 and float(order[2]) < 0:
      sec3.append(order)
    else: 
      sec4.append(order)

  total_sec.append(sec1)
  total_sec.append(sec2)
  total_sec.append(sec3)
  total_sec.append(sec4)
  return total_sec

  #orders in [[s1],[s2],[s3],[s4]]

def number_of_orders_per_sector(orders):
  output = [] 
  for order in orders:
    output.append(len(order))
  return output
  
#returns number of nodes each truck takes (floor)
def NodePerTruck(orders,number_trucks):
  import math
  eachTruck = 0
  eachTruck = len(orders)/number_trucks
  eachTruck = math.ceil(eachTruck)
  return eachTruck

def arrange_order_per_truck(order_in_sections,number_of_trucks_for_each_section):
  # print(order_in_sections)
  # print(number_of_trucks_for_each_section)

  truck_lst = []
  temp_truck_lst= []  # print(order_in_sections[0])
  # print(len(order_in_sections))
  for i in range (len(order_in_sections)):
    temp_order_lst = []
    #create a temp list for orders to remove
    for order in order_in_sections[i]:
      temp_order_lst.append(order)
    for j in range (number_of_trucks_for_each_section[i]):
      temp_truck_lst.append([])
    # print(temp_truck_lst)

    l=0
    while temp_order_lst != []:
      if temp_truck_lst[l] == []:
        order_lst = min_dist_node(temp_order_lst,['0',0,0])
        temp_truck_lst[l].append(order_lst[0])
        temp_order_lst.remove(order_lst)
      else:
        order_lst = min_dist_node(temp_order_lst,order_lst)
        temp_truck_lst[l].append(order_lst[0])
        temp_order_lst.remove(order_lst)
      l+=1
      if l>=len(temp_truck_lst):
        l=0

    truck_lst.append(temp_truck_lst)
  return truck_lst

def number_of_trucks_per_section(number_of_nodes_per_sector,number_trucks,NodePerTruck):

  #create output with no array yet 
  output = [0,0,0,0]

  #each sector has at least 1 truck UNLESS SECTOR IS EMPTY 
  for i in range(len(number_of_nodes_per_sector)):
    if number_of_nodes_per_sector[i] > 0:
      number_trucks-=1
      output[i] +=1
      number_of_nodes_per_sector[i] -= NodePerTruck
      #corner case: Less than 4 trucks
      if number_trucks==0:
        return output

  #Adding based on priority 
  
  while sum(number_of_nodes_per_sector)>0:

    for i in range(len(number_of_nodes_per_sector)):

      maximum = max(number_of_nodes_per_sector)

      if number_trucks==0:
        output_array = []
        for element in output:
          output_array.append([element])
        return output

      if number_of_nodes_per_sector[i] == maximum:
        number_trucks-=1
        output[i] +=1
        number_of_nodes_per_sector[i] -= NodePerTruck

  #Corner case: more trucks than what we need 
  return output

