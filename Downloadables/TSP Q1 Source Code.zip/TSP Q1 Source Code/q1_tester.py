from utility import *
from q1 import schedule_q1
import copy

def legality_checking(truck_paths, order_list, number_trucks):
	check_trucks(truck_paths, number_trucks)
	checking_all_order(truck_paths, order_list)
	if checking_if_airports(truck_paths):
		print("no airport in q1")
		exit()

# replace these parameters with different csv file locations
order_csv = "./dataset/orders_001.csv"
parameter_csv = "./dataset/parameters_001.csv"

number_trucks, truck_speed, plane_speed = parameter_reader(parameter_csv)
orders = list_reader(order_csv)
location_dict = location_dict_generation([orders])

# orders_clone will be used on line 26. just in case your schedule_q1 on line 24 modifies orders
orders_clone = copy.deepcopy(orders) # <--- changed 

# call your function
truck_paths = schedule_q1(orders, number_trucks)  

legality_checking(truck_paths, orders_clone, number_trucks)  # <--- changed
print("Score for q1 is:", scoring_q1(truck_paths, location_dict)) # print your score. the smaller the better






