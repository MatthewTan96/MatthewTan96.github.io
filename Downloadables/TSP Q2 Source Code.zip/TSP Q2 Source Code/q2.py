def schedule_q2(orders, airports, truck_speed, plane_speed, number_trucks):
  import math
  import operator
  #making a copy of the order list to avoid reference error 
  orders_copy = []
  for order in orders:
      orders_copy.append(order)
  #segment points according to closest airport. Put in dictionary 
  airport_dictionary = segment_points(orders_copy,airports)
  # print(airport_dictionary)

  #find the closest airport so that they can fly back 
  closest_airport_to_origin = min_dist_node(airports,[0,0,0])

  #find out how much each truck has to tank on average 
  truck_order_average = math.ceil((len(orders))/number_trucks)
  
  #allocate trucks to each cluster 

  #Find out how many nodes are in each cluster  
  airport_node_dictionary = {}
  for key in airport_dictionary:
    airport_node_dictionary[key] = len(airport_dictionary[key])

  #Case 2: If there are less trucks than clusters
  if number_trucks<len(airport_dictionary):
    truck_allocation_dictionary = {}    
    #Create empty dictionary first
    for airport in airports:
      truck_allocation_dictionary[airport[0]]=0

    # Allocate based on the higher number of nodes 
    while number_trucks > 0:
      highest_node_cluster = (max(airport_node_dictionary, key=airport_node_dictionary.get))
      airport_node_dictionary[highest_node_cluster] -= truck_order_average
      truck_allocation_dictionary[highest_node_cluster] += 1
      number_trucks-=1 

    
    #Take out the clusters that are 0 and add to new list. Remove from current list 
    no_truck_clusters = []
    for sector in truck_allocation_dictionary:
      if truck_allocation_dictionary[sector] == 0:
        no_truck_clusters.append(sector)
    
    # print(no_truck_clusters)
    
    #form best routes for no_truck_clusters
    output_no_truck_clusters = route_allocation_no_truck(orders,airport_dictionary,no_truck_clusters,airports)
    
    # print(output_no_truck_clusters)

    # for cluster in no_truck_clusters:
    #   truck_allocation_dictionary.pop(cluster)

    # print(truck_allocation_dictionary)
    # print(no_truck_clusters)

    # For those that have trucks, allocate the list 
    output_for_non_empty_clusters = route_allocation_empty_clusters(truck_allocation_dictionary,airport_dictionary,orders,closest_airport_to_origin) 
    # print(output_for_non_empty_clusters)

    #include empty ones based on which one have the most space
    final_output = glue_empty_sectors(output_for_non_empty_clusters,output_no_truck_clusters)
    # print(final_output)
    return final_output


  #Case 1: If there are more or equal number of trucks to clusters  
  if number_trucks>=len(airport_dictionary):
      #Create a dictionary of number of trucks allocated  
    truck_allocation_dictionary = {}
    for airport in airports:
      truck_allocation_dictionary[airport[0]]=1
      airport_node_dictionary[airport[0]] -= truck_order_average
      number_trucks-=1

    #allocating based on the one that has the highest number of nodes
    # print(airport_node_dictionary)

    while number_trucks > 0:
      highest_node_cluster = (max(airport_node_dictionary, key=airport_node_dictionary.get))
      airport_node_dictionary[highest_node_cluster] -= truck_order_average
      truck_allocation_dictionary[highest_node_cluster] += 1
      number_trucks-=1
    
    #validate to make sure that it is not over the regulated limit. If over then limit it. If not nevermind
    # print(truck_allocation_dictionary)
    # print(airports)
    for airport in airports: 
      # print(airport[0])
      # print(truck_allocation_dictionary[airport[0]])
      # print(airport[-1])
      if int(truck_allocation_dictionary[airport[0]]) > int(airport[-1]):
        truck_allocation_dictionary[airport[0]] = int(airport[-1])

    output = route_allocation(truck_allocation_dictionary,airport_dictionary,orders,closest_airport_to_origin)
    # print(output)
    return output 

  
def route_allocation_empty_clusters(truck_allocation_dictionary,airport_dictionary,orders,closest_airport_to_origin):
  output = []
  for airport in truck_allocation_dictionary:
    #per sector
    trucks_in_cluster = truck_allocation_dictionary[airport]
    orders_in_cluster = airport_dictionary[airport]

    orders_copy_cluster = []
    for order in orders:
      if order[0] in orders_in_cluster:
        orders_copy_cluster.append(order)

    temp = []
    for x in range(trucks_in_cluster):
      temp.append([])

    while len(orders_in_cluster)>0:
      for i in range (trucks_in_cluster):

        if len(orders_in_cluster)==0:
          break

        if temp[i]==[]:
            start_point = [0,0,0]
        else:
            start_point = temp[i][-1]
            for order in orders:
              if order[0] == start_point:
                  start_point = order

        closest_node = min_dist_node(orders_copy_cluster,start_point)
        temp[i].append(closest_node)
        #remove from orders_in_cluster
        orders_in_cluster.remove(closest_node)

        #remove from orders_copy_cluster 
        for order in orders_copy_cluster:
          if order[0] == closest_node:
            orders_copy_cluster.remove(order)

    #go home by airport 
    for array in temp:
      array += [airport] + [closest_airport_to_origin]
    
    #append to output 
    for array in temp:
      output.append(array)
  return output

def glue_empty_sectors(output_for_non_empty_clusters,output_no_truck_clusters):
  # print(output_for_non_empty_clusters)
  # print(output_no_truck_clusters)
  for airport in output_no_truck_clusters:
    
    #find smallest array 
    smallest_array = min(output_for_non_empty_clusters, key = len)
    # print(smallest_array)
    closest_airport_to_origin = smallest_array[-1]
    print(smallest_array)
    
    # print(airport)
    lst = output_no_truck_clusters[airport]
    lst = smallest_array[:len(smallest_array)-1] + [airport] + lst + [airport] + [closest_airport_to_origin]

    #Make a new copy and reinsert 
    output = []
    for n in range(len(output_for_non_empty_clusters)):
      if output_for_non_empty_clusters[n] == smallest_array:
        output_for_non_empty_clusters[n] = lst
        output.append(lst)
      else:
        output.append(output_for_non_empty_clusters[n])
  return output


  # print(output_for_non_empty_clusters)
  # print(output_no_truck_clusters)

def route_allocation(truck_allocation_dictionary,airport_dictionary,orders,closest_airport_to_origin):
  
  output = []
  # print(truck_allocation_dictionary)
  for airport in airport_dictionary:
    #per sector 

    trucks_in_cluster = truck_allocation_dictionary[airport]
    orders_in_cluster = airport_dictionary[airport]

    #pulling out coordinates for orders_in_cluster from orders_copy 
    orders_copy_cluster = []
    for order in orders:
      if order[0] in orders_in_cluster:
        orders_copy_cluster.append(order)

    temp = []
    for x in range(trucks_in_cluster):
      temp.append([])

    while len(orders_in_cluster)>0:
      for i in range (trucks_in_cluster):

        if len(orders_in_cluster)==0:
          break

        if temp[i]==[]:
            start_point = [0,0,0]
        else:
            start_point = temp[i][-1]
            for order in orders:
              if order[0] == start_point:
                  start_point = order

        closest_node = min_dist_node(orders_copy_cluster,start_point)
        temp[i].append(closest_node)
        #remove from orders_in_cluster
        orders_in_cluster.remove(closest_node)

        #remove from orders_copy_cluster 
        for order in orders_copy_cluster:
          if order[0] == closest_node:
            orders_copy_cluster.remove(order)

    #go home by airport 
    for array in temp:
      array += [airport] + [closest_airport_to_origin]
    
    #append to output 
    for array in temp:
      output.append(array)
  return output

    
def route_allocation_no_truck(orders,airport_dictionary,no_truck_clusters,airports):
  output = {}
  # print(no_truck_clusters)
  for cluster in no_truck_clusters:
    #for each cluster

    temp = []
    orders_copy_cluster = []
    for order in orders:
      if order[0] in airport_dictionary[cluster]:
        orders_copy_cluster.append(order)
    
    while len(airport_dictionary[cluster])>0:

      if temp==[]:
        for airport in airports:
          if airport[0] == cluster:
            start_point = airport
      else:
        start_point = temp[-1]
        for order in orders:
          if order[0] == start_point:
              start_point = order

      closest_node = min_dist_node(orders_copy_cluster,start_point)
      temp.append(closest_node)
      # print(closest_node)
      # print(airport_dictionary[cluster])

      #remove from airport_dictionary
      airport_dictionary[cluster].remove(closest_node)

      #remove from orders_copy_cluster 
      for order in orders_copy_cluster:
        if order[0] == closest_node:
          orders_copy_cluster.remove(order)

    output[cluster] = temp
  return output


def segment_points(orders,airports):
    new_dict = {}
    for airport in airports:
            new_dict[airport[0]] = []
    while len(orders)>0:
        for order in orders: 
            closest_airport = min_dist_node(airports,order)
            new_dict[closest_airport] += [order[0]]
            orders.remove(order)
    return new_dict


def min_dist_node(lst,start_point):
    order_dict = {}
    for i in range(len(lst)):
      start = start_point
      compare = lst[i]
      distance = ((float(start[1])-float(compare[1]))**2 +(float(start[2])-float(compare[2]))**2)**0.5
      order_dict[lst[i][0]] = distance

    min_node = min(order_dict,key=order_dict.get)
    
    for element in lst:
      if element[0] == min_node:
        return element[0]

def distance_calculation(location_A, location_B):
    return (((float(location_A[1])) - float(location_B[1])) ** 2 + (float(location_A[2]) - float(location_B[2])) ** 2) ** 0.5
